This module configures and creates aliases in the HTTP Daemon integrated in the Agent.
These aliases are usefull to redirect the game server downloads.
